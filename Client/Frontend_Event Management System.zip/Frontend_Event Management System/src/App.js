
import './App.css';
import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux"; // Import useDispatch and useSelector
import { login, logout } from "./store/userSlice"; // Import Redux actions
import Registration from "./Pages/auth/Registration";
import Login from "./Pages/auth/login";
import AdminDashboard from "./Pages/Admin/AdminDashboard";
import UserDashboard from "./Pages/User/UserDashboard";
import EventList1 from './Pages/Admin/Event_Curd/EventLists';
import CreateEvent from './Pages/Admin/Event_Curd/CreateEvent';
import EditEvent from './Pages/Admin/Event_Curd/EditEvent';
import ViewEvent from './Pages/Admin/Event_Curd/ViewEvent';
import UserRegList from './Pages/Admin/UserReg_CURD/UserRegList';
import CreateUser from './Pages/Admin/UserReg_CURD/CreateUser';
import EditUser from './Pages/Admin/UserReg_CURD/EditUser';
import ViewUser from './Pages/Admin/UserReg_CURD/ViewUser';
import RegisteredUsers from './Components/RegisteredUsers';
import Home from './Pages/Home';
import UserEventList from './Pages/User/UserEventList';
import Navbar from "./Components/Navbar";
import Profile from './Components/Profile';
import UserRegisteredEvents from './Components/UserRegisteredEvents';

function App() {
    const dispatch = useDispatch(); // Redux dispatch function
    const isAuthenticated = useSelector((state) => state.user.isAuthenticated); // Get isAuthenticated from Redux
    const role = useSelector((state) => state.user.role); // Get role from Redux

    // Check localStorage for user data on page load
    useEffect(() => {
        const user = JSON.parse(localStorage.getItem("user"));
        if (user) {
            dispatch(login(user)); // Dispatch login action to update Redux state
        }
    }, [dispatch]);

    // Handle logout
    const handleLogout = () => {
        dispatch(logout()); // Dispatch logout action
        localStorage.removeItem("user");
    };

    return (
        <Router>
            <Navbar isAuthenticated={isAuthenticated} role={role} onLogout={handleLogout} />
            <Routes>
                {/* Redirect root path to /login */}
                <Route path="/" element={<Home />} />

                {/* Authentication Routes */}
                <Route path="/register" element={<Registration />} />
                <Route
                    path="/login"
                    element={<Login />} // No need to pass onLogin prop
                />
                <Route path="/profile" element={<Profile />} />

                {/* Admin and User Dashboards */}
                <Route path="/admin/dashboard" element={<AdminDashboard />} />
                <Route path="/user/dashboard" element={<UserDashboard />} />

                {/* Event CRUD Routes */}
                <Route path="/admin/events" element={<EventList1 />} />
                <Route path="/admin/events/create" element={<CreateEvent />} />
                <Route path="/admin/events/edit/:eventId" element={<EditEvent />} />
                <Route path="/admin/events/view/:eventId" element={<ViewEvent />} />
                <Route path="/admin/events/:eventId/registered-users" element={<RegisteredUsers />}/>

                {/* User CRUD Routes */}
                <Route path="/admin/users" element={<UserRegList />} />
                <Route path="/admin/users/create" element={<CreateUser />} />
                <Route path="/admin/users/edit/:userId" element={<EditUser />} />
                <Route path="/admin/users/view/:userId" element={<ViewUser />} />

                {/* User Event Routes */}
                <Route path="/user/events/:eventId" element={<UserEventList />} /> 
                <Route path="/user/registeredevents" element={<UserRegisteredEvents />} />
            </Routes>
        </Router>
    );
}

export default App;