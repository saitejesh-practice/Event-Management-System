import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux"; // Import useDispatch and useSelector
import { logout } from "../store/userSlice"; // Import the logout action
import "./Navbar.css";
import navimg from "../Images/logo4.png";

const Navbar = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch(); // Redux dispatch function
    const isAuthenticated = useSelector((state) => state.user.isAuthenticated); // Get isAuthenticated from Redux
    const role = useSelector((state) => state.user.role); // Get role from Redux

    const handleLogout = () => {
        dispatch(logout()); // Dispatch logout action
        localStorage.removeItem("user");
        navigate("/login");
    };

    return (
        <nav className="navbar sticky-navbar">
            <div className="navbar-container">
                <div className="logo">
                    <Link to="/">
                        <img src={navimg} alt="Event Logo" height="20px" width="30px" title="Events" />
                    </Link>
                </div>

                <input type="checkbox" id="menu-toggle" />
                <label htmlFor="menu-toggle" className="menu-button">
                    ☰
                </label>
                <ul className="nav-links">
                    {isAuthenticated ? (
                        role === "Admin" ? (
                            <>
                                <li><Link to="/admin/dashboard">Admin Dashboard</Link></li>
                                <li><Link to="/admin/events">Manage Events</Link></li>
                                <li><Link to="/admin/users">Manage Users</Link></li>
                                
                            </>
                        ) : (
                            <>
                                <li><Link to="/user/dashboard">User Dashboard</Link></li>
                                
                                <li><Link to="/user/registeredevents">Registered Events</Link></li>
                                <li><Link to="/profile">Profile</Link></li> 
                            </>
                        )
                    ) : (
                        <>
                            <li><Link to="/login">Login</Link></li>
                            <li><Link to="/register">Register</Link></li>
                        </>
                    )}
                    {isAuthenticated && <li><button onClick={handleLogout} className="logout-button">Logout</button></li>}
                </ul>
            </div>
        </nav>
    );
};

export default Navbar;