// src/Components/Profile.js
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux"; // To access userId from Redux store
import userService from "../Services/userService"; // Import UserService to fetch user data
import "./Profile.css"; // Optional: Add styles for the profile page

const Profile = () => {
    const [user, setUser] = useState(null); // State to store user data
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(null); // Error state

    // Get userId from Redux store
    const userId = useSelector((state) => state.user.userId);

    // Fetch user data when the component mounts
    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const userData = await userService.getUserById(userId); // Fetch user data by userId
                setUser(userData);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching user profile:", error);
                setError(error);
                setLoading(false);
            }
        };

        if (userId) {
            fetchUserProfile();
        }
    }, [userId]);

    // Display loading state
    if (loading) return <p>Loading profile...</p>;

    // Display error state
    if (error) return <p>Error: {error.message}</p>;

    // Display user profile
    return (
        <div className="profile-container">
            <h1>Profile</h1>
            {user ? (
                <div className="profile-details">
                    <p><strong>User ID:</strong> {user.userId}</p>
                    <p><strong>Name:</strong> {user.name}</p>
                    <p><strong>Email:</strong> {user.email}</p>
                    <p><strong>Password:</strong> {user.passwordHash}</p>
                    <p><strong>Role:</strong> {user.role}</p>
                    {/* Add more fields as needed */}
                </div>
            ) : (
                <p>No user data found.</p>
            )}
        </div>
    );
};

export default Profile;