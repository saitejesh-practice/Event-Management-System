// src/Pages/RegisteredUsers.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import RSVPService from "../Services/RSVPService";
import { useDispatch } from "react-redux";
import { toggleAttended } from "../store/rsvpSlice";
import sendEmail from "../Services/emailService"; // Import email service

const RegisteredUsers = () => {
    const { eventId } = useParams(); // Get eventId from URL
    const [registeredUsers, setRegisteredUsers] = useState([]);
    const [eventDetails, setEventDetails] = useState(null); // State for event details
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    // Fetch registered users and event details
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetch data from the backend
                const response = await RSVPService.getRSVPsByEventId(eventId);

                // Set event details and registered users
                setEventDetails(response.event);
                setRegisteredUsers(response.registeredUsers);

                setLoading(false);
            } catch (error) {
                console.error("Error fetching data:", error);
                setError(error);
                setLoading(false);
            }
        };

        fetchData();
    }, [eventId]);

    // Handle toggle isAttended
    const handleToggleAttended = (rsvpId, isAttended) => {
        dispatch(toggleAttended({ rsvpId, isAttended }));
    };

    // Handle send email
    const handleSendEmail = async (userEmail, rsvpId) => {
        if (!eventDetails || !eventDetails.eventDate) {
            console.error("Event details not loaded:", eventDetails);
            alert("Event details not found.");
            return;
        }

        console.log("✅ Event details:", eventDetails); // Debug log

        try {
            // Pass RSVP ID as invitation_id to the email service
            await sendEmail(userEmail, eventDetails, rsvpId);
            alert("Email sent successfully!");
        } catch (error) {
            console.error("❌ Error sending email:", error);
            alert("Failed to send email.");
        }
    };

    if (loading) return <p>Loading registered users...</p>;

    if (error) return <p>Error: {error.message}</p>;

    return (
        <div className="container mt-4">
            <h1>Registered Users for Event: {eventDetails?.eventName}</h1>
            
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>RSVP ID</th>
                        <th>User ID</th>
                        <th>User Name</th>
                        <th>Attended</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {registeredUsers.map((rsvp) => (
                        <tr key={rsvp.rsvpId}>
                            <td>{rsvp.rsvpId}</td>
                            <td>{rsvp.userId}</td>
                            <td>{rsvp.userName}</td>
                            <td>
                                <input
                                    type="checkbox"
                                    checked={rsvp.isAttended}
                                    onChange={(e) =>
                                        handleToggleAttended(rsvp.rsvpId, e.target.checked)
                                    }
                                />
                            </td>
                            <td>
                                <button
                                    onClick={() => handleSendEmail(rsvp.userEmail, rsvp.rsvpId)} // Pass userEmail and RSVP ID here
                                    className="btn btn-primary btn-sm"
                                >
                                    Send Email
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <br/> <br/> <br/>
            <button onClick={() => navigate(-1)} className="btn btn-secondary mb-3">
                Back to Events
            </button>
        </div>
    );
};

export default RegisteredUsers;
