// src/Components/UserRegisteredEvents.js
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux"; // To access userId from Redux store
import RSVPService from "../Services/RSVPService"; // Import RSVPService to fetch registered events
import "./UserRegisteredEvents.css"; // Optional: Add styles for the component

const UserRegisteredEvents = () => {
    const [events, setEvents] = useState([]); // State to store registered events
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(null); // Error state

    // Get userId from Redux store
    const userId = useSelector((state) => state.user.userId);

    // Fetch registered events when the component mounts
    useEffect(() => {
        const fetchRegisteredEvents = async () => {
            try {
                const data = await RSVPService.getRSVPsByUserId(userId); // Fetch events by userId
                setEvents(data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching registered events:", error);
                setError(error);
                setLoading(false);
            }
        };

        if (userId) {
            fetchRegisteredEvents();
        }
    }, [userId]);

    // Display loading state
    if (loading) return <p>Loading registered events...</p>;

    // Display error state
    if (error) return <p>Error: {error.message}</p>;

    // Display registered events
    return (
        <div className="registered-events-container">
            <h1>My Registered Events</h1>
            {events.length > 0 ? (
                <table className="events-table">
                    <thead>
                        <tr>
                            <th>Invitation ID</th>
                            <th>Event ID</th>
                            <th>Event Name</th>
                            <th>Date</th>
                            <th>Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        {events.map((event) => (
                            <tr key={event.rsvpId}>
                                <td>{event.rsvpId}</td>
                                <td>{event.eventId}</td>
                                <td>{event.eventName}</td>
                                <td>{event.eventDate}</td>
                                <td>{event.eventLocation}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No events registered.</p>
            )}
        </div>
    );
};

export default UserRegisteredEvents;