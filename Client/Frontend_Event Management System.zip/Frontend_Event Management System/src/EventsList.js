import React, { useState, useEffect } from "react";
import axios from "axios";

const EventsList = () => {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Fetch events from backend
    useEffect(() => {
        axios.get("https://localhost:7149/api/Event")
            .then(response => {
                console.log("API Response:", response.data);
                setEvents(response.data);
                setLoading(false);
            })
            .catch(error => {
                console.error("There was an error fetching the event data:", error);
                setError(error);
                setLoading(false);
            });
    }, []);

    if (loading) return <p>Loading events...</p>;

    if (error) return <p>Error: {error.message}</p>;

    if (events.length === 0) return <p>No events found.</p>;

    return (
        <div>
            <h1>Available Events</h1>
            <table>
                <thead>
                    <tr>
                        <th>Event ID</th>
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    {events.map(event => (
                        <tr key={event.eventId}>
                            <td>{event.eventId}</td>
                            <td>{event.eventName}</td>
                            <td>{new Date(event.eventDate).toLocaleDateString()}</td>
                            <td>{event.eventLocation}</td>
                            <td>{event.eventDescription}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default EventsList;
