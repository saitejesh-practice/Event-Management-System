// src/pages/AdminDashboard.js
import React from "react";
import { Link } from "react-router-dom";
import {Container,DashboardTitle,CardContainer,Card,ImageWrapper,CardImage,} from "./AdminDashboardStyles";
import manageUsersImg from "../../Images/mu.jpg"; // Import user image
import manageEventsImg from "../../Images/manageevents.png"; // Import events image

const AdminDashboard = () => {
    return (
        <Container>
            <DashboardTitle>Admin Dashboard</DashboardTitle>
            <CardContainer>
                <Link to="/admin/users" className="text-decoration-none">
                    <Card bgColor="#007bff">
                        <ImageWrapper bgColor="#007bff">
                            <CardImage src={manageUsersImg} alt="Manage Users" />
                        </ImageWrapper>
                        <h3>Manage User Registrations</h3>
                        <p>Click here to view and manage user registrations.</p>
                    </Card>
                </Link>
                <Link to="/admin/events" className="text-decoration-none">
                    <Card bgColor="#28a745">
                        <ImageWrapper bgColor="#28a745">
                            <CardImage src={manageEventsImg} alt="Manage Events" />
                        </ImageWrapper>
                        <h3>Manage Events</h3>
                        <p>Click here to view and manage events.</p>
                    </Card>
                </Link>
            </CardContainer>
        </Container>
    );
};

export default AdminDashboard;