// src/pages/AdminDashboardStyles.js
import styled from 'styled-components';
import bg2 from '../../Images/bg2.jpg'; // Import the background image

export const Container = styled.div`
    max-width: 100%; /* Ensure the container takes the full width */
    margin: 0;
    padding: 20px;
    text-align: center;
    background-image: url(${bg2}); /* Set the background image */
    background-size: cover; /* Ensures the image covers the entire container */
    background-position: center; /* Centers the background image */
    background-repeat: no-repeat; /* Prevents the image from repeating */
    min-height: 92vh; /* Ensures the background covers the full viewport height */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-sizing: border-box; /* Ensures padding is included in the height calculation */
`;

export const DashboardTitle = styled.h1`
    margin-bottom: 2rem;
    color: white; /* Change text color to white for better visibility */
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); /* Add shadow to text for better readability */
`;

export const CardContainer = styled.div`
    display: flex;
    justify-content: center;
    gap: 2rem;
    flex-wrap: wrap;
`;

export const Card = styled.div`
    flex: 1 1 calc(50% - 2rem);
    max-width: 400px; /* Reduced card size */
    padding: 1.5rem; /* Reduced padding */
    background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
    border-radius: 12px; /* Rounded edges */
    text-align: center;
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */

    &:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15); /* Enhanced shadow on hover */
    }

    h3 {
        margin-bottom: 1rem;
        color: #333;
    }

    p {
        margin: 0;
        color: #666;
    }
`;

export const ImageWrapper = styled.div`
    width: 80px; /* Reduced size for the circular frame */
    height: 80px; /* Reduced size for the circular frame */
    border-radius: 50%; /* Makes it circular */
    border: 3px solid ${(props) => props.bgColor || '#007bff'};
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden; /* Ensures the image stays within the circle */
    margin: 0 auto 1rem; /* Centers the wrapper and adds margin below */
`;

export const CardImage = styled.img`
    width: 60px; /* Reduced image size */
    height: 60px; /* Reduced image size */
    object-fit: cover; /* Ensures the image fits within the square box */
    border-radius: 8px; /* Slightly rounded corners for the image */
`;