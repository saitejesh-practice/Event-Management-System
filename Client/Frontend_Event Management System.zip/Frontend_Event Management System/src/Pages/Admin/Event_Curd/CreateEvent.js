// src/Pages/Admin/CreateEvent.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import EventService from "../../../Services/EventService";

const CreateEvent = () => {
    const navigate = useNavigate();
    const [event, setEvent] = useState({
        eventName: "",
        eventDate: "",
        eventLocation: "",
        eventDescription: "",
    });
    const [error, setError] = useState("");

    // Handle form input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEvent({ ...event, [name]: value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Use the EventService to create the event
            await EventService.createEvent(event);
            alert("Event created successfully!");
            navigate("/admin/events"); // Redirect to the event list page
        } catch (error) {
            console.error("There was an error creating the event:", error);
            setError("Failed to create event. Please try again.");
        }
    };

    return (
        <div className="container mt-4">
            <h1>Create New Event</h1>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                {/* Event Name Field */}
                <div className="form-group">
                    <label>Event Name</label>
                    <input
                        type="text"
                        className="form-control"
                        name="eventName"
                        value={event.eventName}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Event Date Field */}
                <div className="form-group">
                    <label>Event Date</label>
                    <input
                        type="date"
                        className="form-control"
                        name="eventDate"
                        value={event.eventDate}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Event Location Field */}
                <div className="form-group">
                    <label>Event Location</label>
                    <input
                        type="text"
                        className="form-control"
                        name="eventLocation"
                        value={event.eventLocation}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Event Description Field */}
                <div className="form-group">
                    <label>Event Description</label>
                    <textarea
                        className="form-control"
                        name="eventDescription"
                        value={event.eventDescription}
                        onChange={handleInputChange}
                        rows="3"
                        required
                    ></textarea>
                </div>

                {/* Submit Button */}
                <button type="submit" className="btn btn-primary">
                    Create Event
                </button>
            </form>
        </div>
    );
};

export default CreateEvent;
