// src/Pages/Admin/EditEvent.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import EventService from "../../../Services/EventService";

const EditEvent = () => {
    const { eventId } = useParams();
    const navigate = useNavigate();
    const [event, setEvent] = useState({
        eventName: "",
        eventDate: "",
        eventLocation: "",
        eventDescription: "",
    });
    const [error, setError] = useState("");

    const formatDate = (dateString) => dateString.split("T")[0];

    useEffect(() => {
        const fetchEvent = async () => {
            try {
                const eventData = await EventService.getEventById(eventId);
                setEvent({ ...eventData, eventDate: formatDate(eventData.eventDate) });
            } catch (error) {
                console.error("Error fetching event data:", error);
                setError("Failed to fetch event data. Please try again.");
            }
        };
        fetchEvent();
    }, [eventId]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEvent({ ...event, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await EventService.updateEvent(eventId, event);
            alert("Event updated successfully!");
            navigate("/admin/events");
        } catch (error) {
            console.error("Error updating event:", error);
            setError("Failed to update event. Please try again.");
        }
    };

    const styles = {
        container: { display: "flex", flexDirection: "column", alignItems: "center", marginTop: "20px", fontFamily: "Calibri, sans-serif" },
        form: { width: "100%", maxWidth: "600px", padding: "20px", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", borderRadius: "10px", backgroundColor: "#f9f9f9" },
        formGroup: { marginBottom: "20px", width: "100%" },
        input: { width: "100%", padding: "12px", fontSize: "1.1rem", borderRadius: "5px", border: "1px solid #ddd", fontFamily: "Calibri, sans-serif" },
        textarea: { width: "100%", resize: "none", height: "150px", fontSize: "1.1rem", padding: "10px", lineHeight: "1.4", borderRadius: "5px", border: "1px solid #ddd", fontFamily: "Calibri, sans-serif" },
        buttonContainer: { display: "flex", justifyContent: "center", marginTop: "20px" },
        button: { padding: "12px 24px", fontSize: "1.1rem", borderRadius: "8px", backgroundColor: "#007bff", color: "#fff", border: "none", cursor: "pointer", fontFamily: "Calibri, sans-serif" }
    };

    return (
        <div style={styles.container}>
            <h1>Edit Event</h1>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit} style={styles.form}>
                <div style={styles.formGroup}>
                    <label>Event Name</label>
                    <input
                        type="text"
                        style={styles.input}
                        name="eventName"
                        value={event.eventName}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                <div style={styles.formGroup}>
                    <label>Event Date</label>
                    <input
                        type="date"
                        style={styles.input}
                        name="eventDate"
                        value={event.eventDate}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                <div style={styles.formGroup}>
                    <label>Event Location</label>
                    <input
                        type="text"
                        style={styles.input}
                        name="eventLocation"
                        value={event.eventLocation}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                <div style={styles.formGroup}>
                    <label>Event Description</label>
                    <textarea
                        style={styles.textarea}
                        name="eventDescription"
                        value={event.eventDescription}
                        onChange={handleInputChange}
                        rows="3"
                        required
                    ></textarea>
                </div>

                <div style={styles.buttonContainer}>
                    <button type="submit" style={styles.button}>
                        Update Event
                    </button>
                </div>
            </form>
        </div>
    );
};

export default EditEvent;
