import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import EventService from "../../../Services/EventService";
import { FaTrash } from "react-icons/fa"; // Import the trash icon

const EventList1 = () => {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Fetch events from the API
    useEffect(() => {
        fetchEvents();
    }, []);

    const fetchEvents = async () => {
        try {
            const data = await EventService.getAllEvents();
            setEvents(data);
            setLoading(false);
        } catch (error) {
            console.error("Error fetching events:", error);
            setError(error);
            setLoading(false);
        }
    };

    // Handle delete event
    const handleDelete = async (eventId) => {
        try {
            await EventService.deleteEvent(eventId);
            alert("Event deleted successfully!");
            fetchEvents(); // Refresh the event list
        } catch (error) {
            console.error("Error deleting event:", error);
        }
    };

    // Format date to display only the date (without time)
    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString(); // Format as "MM/DD/YYYY" (or locale-specific format)
    };

    if (loading) return <p>Loading events...</p>;

    if (error) return <p>Error: {error.message}</p>;

    return (
        <div className="container">
            <h1>Event List</h1>
            <Link to="/admin/events/create" className="btn btn-success mb-3">
                Create New Event
            </Link>
            <br /> <br /> <br />
            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>Event ID</th>
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {events.map((event) => (
                        <tr key={event.eventId}>
                            <td>{event.eventId}</td>
                            <td>{event.eventName}</td>
                            <td>{formatDate(event.eventDate)}</td> {/* Format the date */}
                            <td>{event.eventLocation}</td>
                            <td>
                                <Link
                                    to={`/admin/events/edit/${event.eventId}`}
                                    className="btn btn-warning btn-sm mr-2"
                                >
                                    Edit
                                </Link>
                                <Link
                                    to={`/admin/events/view/${event.eventId}`}
                                    className="btn btn-info btn-sm mr-2"
                                >
                                    View
                                </Link>
                                {/* Trash icon clickable button */}
                                <FaTrash
                                    className="trash-icon"
                                    onClick={() => handleDelete(event.eventId)}
                                />
                                <Link
                                    to={`/admin/events/${event.eventId}/registered-users`}
                                    className="btn btn-primary btn-sm"
                                >
                                    View Registered Users
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default EventList1;