// src/Pages/Admin/ViewEvent.js
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import EventService from "../../../Services/EventService";

const ViewEvent = () => {
    const { eventId } = useParams(); // Get eventId from the URL
    const [event, setEvent] = useState({
        eventName: "",
        eventDate: "",
        eventLocation: "",
        eventDescription: "",
    });
    const [error, setError] = useState(""); // Error message

    // Fetch event details by eventId
    useEffect(() => {
        const fetchEvent = async () => {
            try {
                const eventData = await EventService.getEventById(eventId);
                setEvent(eventData);
            } catch (error) {
                console.error("There was an error fetching the event data:", error);
                setError("Failed to fetch event data. Please try again.");
            }
        };
        fetchEvent();
    }, [eventId]);

    return (
        <div className="container mt-4">
            <h1>Event Details</h1>
            {error && <div className="alert alert-danger">{error}</div>} 
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">{event.eventName}</h5>
                    <p className="card-text">
                        <strong>Date:</strong> {event.eventDate}
                    </p>
                    <p className="card-text">
                        <strong>Location:</strong> {event.eventLocation}
                    </p>
                    <p className="card-text">
                        <strong>Description:</strong> {event.eventDescription}
                    </p>
                    <Link to="/admin/events" className="btn btn-primary">
                        Back to Event List
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ViewEvent;
