// src/Pages/Admin/CreateUser.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import userService from "../../../Services/userService";
const CreateUser = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        role: "User",
        passwordHash: "", // Password field
    });
    const [error, setError] = useState(""); // Eraror message

    // Handle form input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Use the userService to create the user
            await userService.createUser(user);
            alert("User created successfully!");
            navigate("/admin/users"); // Redirect to the user list page
        } catch (error) {
            console.error("There was an error creating the user:", error);
            setError("Failed to create user. Please try again.");
        }
    };

    return (
        <div className="container mt-4">
            <h1>Create New User</h1>
            {error && <div className="alert alert-danger">{error}</div>}{" "}
            {/* Display error message */}
            <form onSubmit={handleSubmit}>
                {/* Name Field */}
                <div className="form-group">
                    <label>Name</label>
                    <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={user.name}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Email Field */}
                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={user.email}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Phone Number Field */}
                <div className="form-group">
                    <label>Phone Number</label>
                    <input
                        type="text"
                        className="form-control"
                        name="phoneNumber"
                        value={user.phoneNumber}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Password Field */}
                <div className="form-group">
                    <label>Password</label>
                    <input
                        type="password"
                        className="form-control"
                        name="passwordHash"
                        value={user.passwordHash}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Role Field */}
                <div className="form-group">
                    <label>Role</label>
                    <select
                        className="form-control"
                        name="role"
                        value={user.role}
                        onChange={handleInputChange}
                    >
                        <option value="User">User</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>

                {/* Submit Button */}
                <button type="submit" className="btn btn-primary">
                    Create User
                </button>
            </form>
        </div>
    );
};

export default CreateUser;