// src/Pages/Admin/EditUser.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import userService from "../../../Services/userService";
const EditUser = () => {
    const { userId } = useParams(); // Get userId from the URL
    const navigate = useNavigate();
    const [user, setUser] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        role: "User",
    });
    const [error, setError] = useState(""); // Error message

    // Fetch user details by userId
    useEffect(() => {
        const fetchUser = async () => {
            try {
                const userData = await userService.getUserById(userId); // Use userService to fetch user
                setUser(userData);
            } catch (error) {
                console.error("There was an error fetching the user data:", error);
                setError("Failed to fetch user data. Please try again.");
            }
        };
        fetchUser();
    }, [userId]);

    // Handle form input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await userService.updateUser(userId, user); // Use userService to update user
            alert("User updated successfully!");
            navigate("/admin/users"); // Redirect to the user list page
        } catch (error) {
            console.error("There was an error updating the user:", error);
            setError("Failed to update user. Please try again.");
        }
    };

    return (
        <div className="container mt-4">
            <h1>Edit User</h1>
            {error && <div className="alert alert-danger">{error}</div>}{" "}
            {/* Display error message */}
            <form onSubmit={handleSubmit}>
                {/* Name Field */}
                <div className="form-group">
                    <label>Name</label>
                    <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={user.name}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Email Field */}
                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={user.email}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Phone Number Field */}
                <div className="form-group">
                    <label>Phone Number</label>
                    <input
                        type="text"
                        className="form-control"
                        name="phoneNumber"
                        value={user.phoneNumber}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Role Field */}
                <div className="form-group">
                    <label>Role</label>
                    <select
                        className="form-control"
                        name="role"
                        value={user.role}
                        onChange={handleInputChange}
                    >
                        <option value="User">User</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>

                {/* Submit Button */}
                {/* Submit Button */}
                <div style={{ display: "flex", justifyContent: "center", marginTop: "15px" }}>
                    <button type="submit" className="btn btn-primary">
                        Update User
                    </button>
                </div>
                
            </form>
        </div>
    );
};

export default EditUser;