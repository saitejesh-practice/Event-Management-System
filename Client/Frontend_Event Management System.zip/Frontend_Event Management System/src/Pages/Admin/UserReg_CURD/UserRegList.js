// src/Pages/Admin/UserRegList.js
import "./UserRegList.css";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import userService from "../../../Services/userService";

const UserRegList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Fetch users from the API
    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const data = await userService.getUsers(); // Use userService to fetch users
            setUsers(data);
            setLoading(false);
        } catch (error) {
            console.error("There was an error fetching the user data:", error);
            setError(error);
            setLoading(false);
        }
    };

    // Handle delete user
    const handleDelete = async (userId) => {
        try {
            await userService.deleteUser(userId); // Use userService to delete user
            alert("User deleted successfully!");
            fetchUsers(); // Refresh the user list
        } catch (error) {
            console.error("There was an error deleting the user:", error);
        }
    };

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>Error: {error.message}</p>;
    }

    return (
        <div className="container mt-4">
            <h1>UserReg List</h1>
            <Link to="/admin/users/create" className="btn btn-success mb-3">
                Create New User
            </Link>
            <br/> <br/> <br/>
            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.userId}>
                            <td>{user.userId}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            
                            <td>{user.role}</td>
                            <td>
                                <Link
                                    to={`/admin/users/edit/${user.userId}`}
                                    className="btn btn-warning btn-sm mr-2"
                                >
                                    Edit
                                </Link>
                                <Link
                                    to={`/admin/users/view/${user.userId}`}
                                    className="btn btn-info btn-sm mr-2"
                                >
                                    View
                                </Link>
                                <button
                                    onClick={() => handleDelete(user.userId)}
                                    className="btn btn-danger btn-sm"
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default UserRegList;