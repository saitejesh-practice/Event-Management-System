// src/Pages/Admin/ViewUser.js
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import userService from "../../../Services/userService";
const ViewUser = () => {
    const { userId } = useParams(); // Get userId from the URL
    const [user, setUser] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        role: "",
    });
    const [error, setError] = useState(""); // Error message

    // Fetch user details by userId
    useEffect(() => {
        const fetchUser = async () => {
            try {
                const userData = await userService.getUserById(userId); // Use userService to fetch user
                setUser(userData);
            } catch (error) {
                console.error("There was an error fetching the user data:", error);
                setError("Failed to fetch user data. Please try again.");
            }
        };
        fetchUser();
    }, [userId]);

    return (
        <div className="container mt-4">
            <h1>User Details</h1>
            {error && <div className="alert alert-danger">{error}</div>}{" "}
            {/* Display error message */}
            <div className="card">
                <div className="card-body">
                    <p className="card-text"><strong>Name: </strong>{user.name}</p>
                    <p className="card-text">
                        <strong>Email:</strong> {user.email}
                    </p>
                    <p className="card-text">
                        <strong>Phone Number:</strong> {user.phoneNumber}
                    </p>
                    <p className="card-text">
                        <strong>Role:</strong> {user.role}
                    </p>
                    <Link to="/admin/users" className="btn btn-primary">
                        Back to User List
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ViewUser;