// src/Pages/Home.js
import React from "react";
import "./Home.css";
import homeImage from "../Images/HomeImg.jpg";

const Home = () => {
    return (
        <div className="home-container">
            <div className="hero-section">
                <div className="hero-text">
                    <h1>Welcome to <br/>Easy Events</h1>
                    <p>Your one-stop platform to manage and attend publically available events seamlessly!</p>
                </div>
                <div className="hero-image">
                    <img src={homeImage} alt="Event management homepage" />
                </div>
            </div>

            <footer className="footer">
                <div className="footer-content">
                    <p>&copy; 2025 Event Management System. All rights reserved.</p>
                    <div className="footer-links">
                        <a href="/aboutus">About Us</a>
                        <a href="/contactus">Contact Us</a>
                    </div>
                    <p>Address: 123 Event St, EventCity, EC 45678 | Phone: +123 456 7890</p>
                </div>
            </footer>
        </div>
    );
};

export default Home;