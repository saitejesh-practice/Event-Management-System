// src/pages/UserDashboard.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import EventService from "../../Services/EventService";  // Import EventService to fetch events
import "./UserDashboard.css"; // Optional: Add styles for the dashboard

const UserDashboard = () => {
    const [events, setEvents] = useState([]); // State to store events
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(null); // Error state
    const navigate = useNavigate(); // For navigation

    // Fetch events when the component mounts
    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const data = await EventService.getAllEvents(); // Fetch all events
                setEvents(data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching events:", error);
                setError(error);
                setLoading(false);
            }
        };

        fetchEvents();
    }, []);

    // Handle "Know More" button click
    const handleKnowMore = (eventId) => {
        navigate(`/user/events/${eventId}`); // Redirect to UserEventList with eventId
    };

    // Display loading state
    if (loading) return <p>Loading events...</p>;

    // Display error state
    if (error) return <p>Error: {error.message}</p>;

    return (
        <div className="container mt-4">
            <h1>User Dashboard</h1>
            <p>Welcome, User! Here are the available events:</p>
            <table className="events-table">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {events.map((event) => (
                        <tr key={event.eventId}>
                            <td>{event.eventName}</td>
                            <td>{event.eventLocation}</td>
                            <td>{event.eventDate}</td>
                            <td>
                                <button
                                    onClick={() => handleKnowMore(event.eventId)}
                                    className="know-more-button"
                                >
                                    Know More
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default UserDashboard;