// src/pages/UserEventList.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import EventService from "../../Services/EventService";
import RSVPService from "../../Services/RSVPService";
import "./UserEventList.css";

const UserEventList = () => {
    const { eventId } = useParams();
    const navigate = useNavigate();
    const [event, setEvent] = useState(null);
    const [user, setUser] = useState(null); // Full user object
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Fetch user details from localStorage
    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem("user"));
        if (!storedUser || !storedUser.userId) {
            alert("User not logged in.");
            navigate("/login");
            return;
        }
        setUser(storedUser);
    }, [navigate]);

    // Fetch event details
    useEffect(() => {
        const fetchEventDetails = async () => {
            try {
                const eventData = await EventService.getEventById(eventId);
                setEvent(eventData);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching event details:", error);
                setError("Failed to fetch event details.");
                setLoading(false);
            }
        };
        fetchEventDetails();
    }, [eventId]);

    // Handle RSVP creation
    const handleRegister = async () => {
        if (!user || !event) {
            alert("User or event details missing.");
            return;
        }

        try {
            const rsvpData = {
                eventId: event.eventId,
                event: {
                    eventId: event.eventId,
                    eventName: event.eventName,
                    eventDate: event.eventDate.split("T")[0],
                    eventLocation: event.eventLocation,
                    eventDescription: event.eventDescription,
                },
                userId: user.userId,
                userReg: {
                    userId: user.userId,
                    name: user.name,
                    email: user.email,
                    passwordHash: user.passwordHash, // Ensure no undefined
                    phoneNumber: user.phoneNumber, // Ensure no undefined
                    role: user.role,
                },
                isAttended: true,
            };

            console.log("RSVP Data being sent:", rsvpData);

            const response = await RSVPService.createRSVP(rsvpData);
            console.log("RSVP Response:", response);

            alert("You successfully registered for the event!");
            navigate("/user/dashboard");
        } catch (error) {
            console.error("Error registering for the event:", error.response?.data);
            alert("Failed to register for the event.");
        }
    };

    if (loading) return <p>Loading event details...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div className="container mt-4">
            <h1>Event Details</h1>
            {event ? (
                <div className="event-details">
                    <p><strong>Event Name:</strong> {event.eventName}</p>
                    <p><strong>Location:</strong> {event.eventLocation}</p>
                    <p><strong>Date:</strong> {event.eventDate.split("T")[0]}</p>
                    <p><strong>Description:</strong> {event.eventDescription}</p>
                    <button onClick={handleRegister} className="register-button">
                        Yes, I will attend
                    </button>
                </div>
            ) : (
                <p>No event details found.</p>
            )}
        </div>
    );
};

export default UserEventList;
