import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../../Services/authService";
import "../auth/login.css"; // Importing the same CSS used in Login.js
import loginIcon from "../../Images/login.png"; // Import the login icon image

const Registration = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState({
        name: "",
        email: "",
        passwordHash: "",
        phoneNumber: "",
        role: "User", // Default role
    });
    const [error, setError] = useState("");

    // Handle form input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await AuthService.register(user);
            alert("Registration successful! Please log in.");
            navigate("/login"); // Redirect to login page after successful registration
        } catch (error) {
            console.error("Registration failed:", error);
            setError("Registration failed. Please try again.");
        }
    };

    return (
        <div>
        <div className="login-container"> {/* Use the same background styling */}
        
            <div className="page-container"> {/* Reuse the card box styling */}
                 <img src={loginIcon} alt="Login Icon" className="login-icon" />
                 <br/> <br/>
                <h1>Register</h1>
                {error && <div className="alert alert-danger">{error}</div>}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Name</label>
                        <input
                            type="text"
                            className="form-control"
                            name="name"
                            value={user.name}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Email</label>
                        <input
                            type="email"
                            className="form-control"
                            name="email"
                            value={user.email}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            className="form-control"
                            name="passwordHash"
                            value={user.passwordHash}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Phone Number</label>
                        <input
                            type="text"
                            className="form-control"
                            name="phoneNumber"
                            value={user.phoneNumber}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Register
                    </button>
                    <br/>
                    <a href="/login">Sign in</a>
                </form>
            </div>
        </div>
        </div>
    );
};

export default Registration;
