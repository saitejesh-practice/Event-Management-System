import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux"; // Import useDispatch
import { login } from "../../store/userSlice"; // Import the login action
import AuthService from "../../Services/authService";
import "./login.css";
import loginIcon from "../../Images/login.png";

const Login = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch(); // Redux dispatch function
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const user = await AuthService.login(email, password);
            alert("Login successful!");

            // Dispatch user data to Redux store
            dispatch(login({
                userId: user.userId,
                role: user.role,
                email: user.email,
            }));

            // Save user data in localStorage
            localStorage.setItem("user", JSON.stringify(user));

            // Redirect based on role
            if (user.role === "Admin") {
                navigate("/admin/dashboard");
            } else if (user.role === "User") {
                navigate("/user/dashboard");
            }
        } catch (error) {
            console.error("Login failed:", error);
            setError("Invalid email or password. Please try again.");
        }
    };

    return (
        <div>
            <div className="login-container">
                <div className="page-container">
                    <img src={loginIcon} alt="Login Icon" className="login-icon" />
                    <br /><br />
                    <h1>Login</h1>
                    {error && <div className="alert alert-danger">{error}</div>}
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>Email</label>
                            <input
                                type="email"
                                className="form-control"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <input
                                type="password"
                                className="form-control"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-primary">
                            Login
                        </button>
                        <br />
                        <a href="/register">Sign Up</a>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;