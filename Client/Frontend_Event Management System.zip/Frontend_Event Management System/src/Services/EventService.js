// src/services/EventService.js
import apiClient from "./apiClient";

const EventService = {
    // Fetch all events
    getAllEvents: async () => {
        try {
            const response = await apiClient.get("/Event");
            return response.data;
        } catch (error) {
            console.error("Error fetching events:", error);
            throw error;
        }
    },

    // Fetch a single event by ID
    getEventById: async (eventId) => {
        try {
            const response = await apiClient.get(`/Event/${eventId}`);
            return response.data;
        } catch (error) {
            console.error("Error fetching event:", error);
            throw error;
        }
    },

    // Create a new event
    createEvent: async (eventData) => {
        try {
            const response = await apiClient.post("/Event", eventData);
            return response.data;
        } catch (error) {
            console.error("Error creating event:", error);
            throw error;
        }
    },

    // Update an existing event
    updateEvent: async (eventId, eventData) => {
        try {
            const response = await apiClient.put(`/Event/${eventId}`, eventData);
            return response.data;
        } catch (error) {
            console.error("Error updating event:", error);
            throw error;
        }
    },

    // Delete an event by ID
    deleteEvent: async (eventId) => {
        try {
            const response = await apiClient.delete(`/Event/${eventId}`);
            return response.data;
        } catch (error) {
            console.error("Error deleting event:", error);
            throw error;
        }
    },
};

export default EventService;
