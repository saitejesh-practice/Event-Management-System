// src/services/RSVPService.js
import apiClient from "./apiClient"; // Reuse the existing Axios instance

const RSVPService = {
    // Fetch all RSVPs
    getAllRSVPs: async () => {
        try {
            const response = await apiClient.get("/rsvp");
            return response.data;
        } catch (error) {
            console.error("Error fetching RSVPs:", error);
            throw error;
        }
    },

    // Fetch an RSVP by ID
    getRSVPById: async (id) => {
        try {
            const response = await apiClient.get(`/rsvp/${id}`);
            return response.data;
        } catch (error) {
            console.error("Error fetching RSVP:", error);
            throw error;
        }
    },

    // Fetch RSVPs by userId
    getRSVPsByUserId: async (userId) => {
        try {
            const response = await apiClient.get(`/rsvp/user/${userId}`);
            return response.data;
        } catch (error) {
            console.error("Error fetching RSVPs for user:", error);
            throw error;
        }
    },

    // Fetch RSVPs by eventId
    getRSVPsByEventId: async (eventId) => {
        try {
            const response = await apiClient.get(`/rsvp/event/${eventId}`);
            return response.data;
        } catch (error) {
            console.error("Error fetching RSVPs for event:", error);
            throw error;
        }
    },

    // Create a new RSVP
    createRSVP: async (rsvpData) => {
        try {
            const response = await apiClient.post("/rsvp", rsvpData);
            return response.data;
        } catch (error) {
            console.error("Error creating RSVP:", error.response?.data); // Log the error response
            throw error;
        }
    },

    // Update an RSVP
    updateRSVP: async (id, updatedRSVP) => {
        try {
            const response = await apiClient.put(`/rsvp/${id}`, updatedRSVP);
            return response.data;
        } catch (error) {
            console.error("Error updating RSVP:", error);
            throw error;
        }
    },

    // Delete an RSVP
    deleteRSVP: async (id) => {
        try {
            const response = await apiClient.delete(`/rsvp/${id}`);
            return response.data;
        } catch (error) {
            console.error("Error deleting RSVP:", error);
            throw error;
        }
    },
};

export default RSVPService;
