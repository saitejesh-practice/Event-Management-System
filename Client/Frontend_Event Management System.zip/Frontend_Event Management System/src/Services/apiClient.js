// src/services/apiClient.js
import axios from "axios";

// Create a reusable Axios instance with a base URL
const apiClient = axios.create({
    baseURL: "https://localhost:7149/api", // Replace with your backend API URL
    headers: {
        "Content-Type": "application/json",
    },
});

// Add response interceptors (optional)
apiClient.interceptors.response.use(
    (response) => response,
    (error) => {
        // Handle errors globally
        if (error.response && error.response.status === 401) {
            // Redirect to login if unauthorized (optional, remove if not needed)
            window.location.href = "/login";
        }
        return Promise.reject(error);
    }
);

export default apiClient;