// src/services/AuthService.js
import apiClient from "./apiClient"; // Reuse the existing Axios instance

const AuthService = {
    // Register a new user
    register: async (userData) => {
        try {
            const response = await apiClient.post("/UserReg", userData); // Endpoint for registration
            return response.data;
        } catch (error) {
            console.error("Error registering user:", error);
            throw error;
        }
    },

    // Login user
    login: async (email, password) => {
        try {
            const response = await apiClient.get(`/UserReg/login/${encodeURIComponent(email)}/${encodeURIComponent(password)}`); // Endpoint for login
            return response.data;
        } catch (error) {
            console.error("Error logging in:", error);
            throw error;
        }
    },
};

export default AuthService;