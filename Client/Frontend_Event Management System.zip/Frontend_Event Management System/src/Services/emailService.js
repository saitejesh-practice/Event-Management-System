import emailjs from "emailjs-com";

// Initialize EmailJS with your Public Key
emailjs.init("ZdfxQ9HNxWGgpz9Qh"); // Use your EmailJS Public Key here

const sendEmail = async (userEmail, eventDetails, rsvpId) => {
    if (!eventDetails || !eventDetails.eventDate) {
        console.error("❌ Missing event details or event date:", eventDetails);
        alert("Event details are incomplete.");
        return;
    }

    const templateParams = {
        to_email: userEmail,
        event_name: eventDetails.eventName || "Unknown Event",
        event_date: eventDetails.eventDate?.split("T")[0] || "Date not available",
        event_location: eventDetails.eventLocation || "Location not provided",
        invitation_id: rsvpId, // Add RSVP ID as Invitation ID
        message: "Thank you for registering for the event!",
    };

    console.log("📧 Sending email to:", userEmail);
    console.log("📩 Email content:", templateParams);

    try {
        const response = await emailjs.send(
            "service_smvg1wb", // Your EmailJS service ID
            "template_op5jznv", // Your EmailJS template ID
            templateParams
        );
        console.log("✅ Email sent successfully!", response);
        return response;
    } catch (error) {
        console.error("❌ Error sending email:", error);
        throw error;
    }
};

export default sendEmail;
