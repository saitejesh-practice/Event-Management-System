// src/services/userService.js
import apiClient from "./apiClient"; // Import the reusable Axios instance

const userService = {
    // Fetch all users
    getUsers: async () => {
        try {
            const response = await apiClient.get("/UserReg"); // Full URL: https://localhost:7149/api/users
            return response.data;
        } catch (error) {
            console.error("Error fetching users:", error);
            throw error;
        }
    },

    // Fetch a single user by ID
    getUserById: async (userId) => {
        try {
            const response = await apiClient.get(`/UserReg/${userId}`); // Full URL: https://localhost:7149/api/users/{userId}
            return response.data;
        } catch (error) {
            console.error("Error fetching user:", error);
            throw error;
        }
    },

    // Create a new user
    createUser: async (userData) => {
        try {
            const response = await apiClient.post("/UserReg", userData); // Full URL: https://localhost:7149/api/users
            return response.data;
        } catch (error) {
            console.error("Error creating user:", error);
            throw error;
        }
    },

    // Update an existing user
    updateUser: async (userId, userData) => {
        try {
            const response = await apiClient.put(`/UserReg/${userId}`, userData); // Full URL: https://localhost:7149/api/users/{userId}
            return response.data;
        } catch (error) {
            console.error("Error updating user:", error);
            throw error;
        }
    },

    // Delete a user by ID
    deleteUser: async (userId) => {
        try {
            const response = await apiClient.delete(`/UserReg/${userId}`); // Full URL: https://localhost:7149/api/users/{userId}
            return response.data;
        } catch (error) {
            console.error("Error deleting user:", error);
            throw error;
        }
    },
};

export default userService;