// src/store/rsvpSlice.js
import { createSlice } from "@reduxjs/toolkit";

const rsvpSlice = createSlice({
    name: "rsvp",
    initialState: {
        isAttended: {},
    },
    reducers: {
        toggleAttended: (state, action) => {
            const { rsvpId, isAttended } = action.payload;
            state.isAttended[rsvpId] = isAttended;
        },
    },
});

export const { toggleAttended } = rsvpSlice.actions;

export default rsvpSlice.reducer;