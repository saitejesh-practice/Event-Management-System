// src/store/store.js
import { configureStore } from "@reduxjs/toolkit";
import rsvpReducer from "./rsvpSlice";
import userReducer from "./userSlice"; 
const store = configureStore({
    reducer: {
        rsvp: rsvpReducer,
        user: userReducer, 
    },
});

export default store;