// src/store/userSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    userId: null,
    role: null, // userRole is stored here
    email: null,
    isAuthenticated: false,
};

const userSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        login: (state, action) => {
            const { userId, role, email } = action.payload;
            state.userId = userId;
            state.role = role; // Store userRole
            state.email = email;
            state.isAuthenticated = true;
        },
        logout: (state) => {
            state.userId = null;
            state.role = null; // Clear userRole
            state.email = null;
            state.isAuthenticated = false;
        },
    },
});

export const { login, logout } = userSlice.actions;
export default userSlice.reducer;