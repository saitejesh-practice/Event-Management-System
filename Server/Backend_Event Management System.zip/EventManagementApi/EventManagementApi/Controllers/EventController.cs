﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventManagementApi.Models;
using EventManagementApi.Data;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace EventManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly EventContext _context;

        public EventController(EventContext context)
        {
            _context = context;
        }

        // Create a new event
        [HttpPost]
        public async Task<IActionResult> CreateEvent([FromBody] Event newEvent)
        {
            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetEventById), new { id = newEvent.EventId }, newEvent);
        }

        // Get all events
        [HttpGet]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        // Get event by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var eventData = await _context.Events.FirstOrDefaultAsync(e => e.EventId == id);

            if (eventData == null)
            {
                return NotFound(new { message = "Event not found" });
            }
            return Ok(eventData);
        }

        // Update an event
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event updatedEvent)
        {
            var foundEvent = await _context.Events.FindAsync(id);
            if (foundEvent == null)
            {
                return NotFound(new { message = "Event not found" });
            }

            foundEvent.EventName = updatedEvent.EventName;
            foundEvent.EventDate = updatedEvent.EventDate;
            foundEvent.EventLocation = updatedEvent.EventLocation;
            foundEvent.EventDescription = updatedEvent.EventDescription;

            await _context.SaveChangesAsync();
            return Ok(foundEvent);
        }

        // Delete an event
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var foundEvent = await _context.Events.FindAsync(id);
            if (foundEvent == null)
            {
                return NotFound(new { message = "Event not found" });
            }

            _context.Events.Remove(foundEvent);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Event deleted successfully" });
        }
    }
}