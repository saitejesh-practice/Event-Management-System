﻿// Controllers/RSVPController.cs
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using EventManagementApi.Models;
using EventManagementApi.Data;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RSVPController : ControllerBase
    {
        private readonly EventContext _context;

        public RSVPController(EventContext context)
        {
            _context = context;
        }

        // Create a new RSVP (Simplified)
        [HttpPost]
        public async Task<IActionResult> CreateRSVP([FromBody] RSVP rsvp)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Fetch and link the event and user by ID
            rsvp.Event = await _context.Events.FindAsync(rsvp.EventId);
            rsvp.UserReg = await _context.UserReg.FindAsync(rsvp.UserId);

            if (rsvp.Event == null) return NotFound(new { message = "Event not found" });
            if (rsvp.UserReg == null) return NotFound(new { message = "User not found" });

            _context.RSVP.Add(rsvp);
            await _context.SaveChangesAsync();

            return Ok(new { message = "RSVP created successfully!", rsvp });
        }


        // Get all RSVPs (Simplified output)
        [HttpGet]
        public async Task<IActionResult> GetAllRSVPs()
        {
            var rsvps = await _context.RSVP
                .Include(r => r.Event)
                .Include(r => r.UserReg)
                .Select(r => new
                {
                    r.RSVPId,
                    EventName = r.Event.EventName,
                    UserName = r.UserReg.Name,
                    r.IsAttended
                }).ToListAsync();

            return Ok(rsvps);
        }

        // Get RSVP by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRSVPById(int id)
        {
            var rsvp = await _context.RSVP
                .Include(r => r.Event)
                .Include(r => r.UserReg)
                .Select(r => new
                {
                    r.RSVPId,
                    EventName = r.Event.EventName,
                    UserName = r.UserReg.Name,
                    r.IsAttended
                }).FirstOrDefaultAsync(r => r.RSVPId == id);

            if (rsvp == null) return NotFound(new { message = "RSVP not found." });

            return Ok(rsvp);
        }

        // Update an RSVP
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRSVP(int id, [FromBody] RSVP updatedRSVP)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var rsvp = await _context.RSVP.FindAsync(id);
            if (rsvp == null) return NotFound(new { message = "RSVP not found." });

            // Update RSVP details
            rsvp.IsAttended = updatedRSVP.IsAttended;

            await _context.SaveChangesAsync();
            return Ok(new { message = "RSVP updated successfully!", rsvp });
        }

        // Delete an RSVP
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRSVP(int id)
        {
            var rsvp = await _context.RSVP.FindAsync(id);
            if (rsvp == null) return NotFound(new { message = "RSVP not found." });

            _context.RSVP.Remove(rsvp);
            await _context.SaveChangesAsync();
            return Ok(new { message = "RSVP deleted successfully!" });
        }


        // Get all events registered by a specific user (simplified version)
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetEventsByUser(int userId)
        {
            var rsvps = await _context.RSVP
                .Include(r => r.Event) // Include Event details
                .Where(r => r.UserId == userId) // Filter by userId
                .Select(r => new
                {
                    r.RSVPId,
                    r.Event.EventId,
                    r.Event.EventName,
                    EventDate = r.Event.EventDate.ToString("yyyy-MM-dd"), // Format date nicely
                    r.Event.EventLocation
                })
                .ToListAsync();

            if (!rsvps.Any())
            {
                return NotFound(new { message = "No events found for this user." });
            }

            return Ok(rsvps);
        }

        // Get all RSVPs for a specific event
        //[HttpGet("event/{eventId}")]
        //public async Task<IActionResult> GetRSVPsByEvent(int eventId)
        //{
        //    var rsvps = await _context.RSVP
        //        .Include(r => r.UserReg) // Include User details
        //        .Where(r => r.EventId == eventId) // Filter by eventId
        //        .Select(r => new
        //        {
        //            r.RSVPId,
        //            r.UserReg.UserId,
        //            UserName = r.UserReg.Name,
        //            r.IsAttended
        //        })
        //        .ToListAsync();

        //    if (!rsvps.Any())
        //    {
        //        return NotFound(new { message = "No RSVPs found for this event." });
        //    }

        //    return Ok(rsvps);
        //}
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetRSVPsByEvent(int eventId)
        {
            // Fetch the event details
            var eventDetails = await _context.Events
                .Where(e => e.EventId == eventId)
                .Select(e => new
                {
                    e.EventName,
                    e.EventDate,
                    e.EventLocation
                })
                .FirstOrDefaultAsync();

            if (eventDetails == null)
            {
                return NotFound(new { message = "Event not found." });
            }

            // Fetch RSVPs for the event
            var rsvps = await _context.RSVP
                .Include(r => r.UserReg) // Include User details
                .Where(r => r.EventId == eventId) // Filter by eventId
                .Select(r => new
                {
                    r.RSVPId,
                    r.UserReg.UserId,
                    UserName = r.UserReg.Name,
                    UserEmail = r.UserReg.Email, // Include user's email
                    r.IsAttended
                })
                .ToListAsync();

            if (!rsvps.Any())
            {
                return NotFound(new { message = "No RSVPs found for this event." });
            }

            // Return event details and registered users
            return Ok(new
            {
                Event = eventDetails,
                RegisteredUsers = rsvps
            });
        }


    }
}
