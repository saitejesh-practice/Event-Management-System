﻿using Microsoft.AspNetCore.Mvc;
using EventManagementApi.Models;
using EventManagementApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRegController : ControllerBase
    {
        private readonly EventContext _context;

        public UserRegController(EventContext context)
        {
            _context = context;
        }

        // Get all users
        [HttpGet]
        public async Task<IEnumerable<UserReg>> Get()
        {
            return await _context.UserReg.ToListAsync();
        }

        // Get user by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var user = await _context.UserReg.FindAsync(id);
            if (user == null) return NotFound(new { Message = "User not found" });
            return Ok(user);
        }

        // Get user by Email and PasswordHash
        [HttpGet("login/{email}/{password}")]
        public async Task<IActionResult> GetByEmailPassword(string email, string password)
        {
            var user = await _context.UserReg.FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == password);
            if (user == null) return Unauthorized(new { Message = "Invalid email or password" });
            return Ok(user);
        }

        // Create a new user
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] UserReg newUser)
        {
            if (string.IsNullOrWhiteSpace(newUser.PasswordHash))
                return BadRequest(new { Message = "Password cannot be empty" });

            _context.UserReg.Add(newUser);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = newUser.UserId }, newUser);
        }

        // Update user
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] UserReg updatedUser)
        {
            var user = await _context.UserReg.FindAsync(id);
            if (user == null) return NotFound(new { Message = "User not found" });

            user.Name = updatedUser.Name;
            user.Email = updatedUser.Email;
            user.PhoneNumber = updatedUser.PhoneNumber;

            if (!string.IsNullOrWhiteSpace(updatedUser.PasswordHash))
            {
                user.PasswordHash = updatedUser.PasswordHash;
            }

            user.Role = updatedUser.Role;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Delete user
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var user = await _context.UserReg.FindAsync(id);
            if (user == null) return NotFound(new { Message = "User not found" });

            _context.UserReg.Remove(user);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
