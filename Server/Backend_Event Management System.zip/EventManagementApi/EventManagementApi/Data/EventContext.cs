﻿using Microsoft.EntityFrameworkCore;
using EventManagementApi.Models;
using System.Reflection.Emit;

namespace EventManagementApi.Data
{
    public class EventContext : DbContext
    {

        public EventContext(DbContextOptions<EventContext> options) : base(options)
        {


        }

        public DbSet<UserReg> UserReg { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<RSVP> RSVP { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Ensure SQL Server provider is detected
            if (Database.ProviderName == "Microsoft.EntityFrameworkCore.SqlServer")
            {
                // Set starting value for EventId
                modelBuilder.Entity<Event>()
                    .Property(e => e.EventId)
                    .UseIdentityColumn(500, 1); // Start from 500, increment by 1

                // Set starting value for RSVPId
                modelBuilder.Entity<RSVP>()
                    .Property(r => r.RSVPId)
                    .UseIdentityColumn(1000, 1); // Start from 1000, increment by 1
            }

            base.OnModelCreating(modelBuilder);
        }
    }
}
