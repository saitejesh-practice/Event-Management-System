﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventManagementApi.Models
{
    public class Event
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int EventId { get; set; } // Primary key

        [Required]
        [StringLength(100)]
        public string? EventName { get; set; } // Name of the event

        [Required]
        [DataType(DataType.Date)]
        public DateTime EventDate { get; set; } // Date and time of the event

        [Required]
        [StringLength(100)]
        public string? EventLocation { get; set; } // Location of the event

        public string? EventDescription { get; set; } // Optional description of the event

       

    
    }
}