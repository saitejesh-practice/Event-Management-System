﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventManagementApi.Models
{
    public class RSVP
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int RSVPId { get; set; }

        [Required]
        public int EventId { get; set; } // Foreign key to Event

        [ForeignKey("EventId")]
        public Event Event { get; set; }

        [Required]
        public int UserId { get; set; } // Foreign key to User

        [ForeignKey("UserId")]
        public UserReg UserReg { get; set; }

        [Required]
        public bool IsAttended { get; set; } // e.g., true for going, false for not going
    }
}
